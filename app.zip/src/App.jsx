import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, IndexRoute, browserHistory, hashHistory } from 'react-router';
import {AppIndex} from './AppIndex.jsx';
import {AppAbout} from './AppAbout.jsx';


class App extends React.Component {


    constructor(props, context) {
        super(props, context);

        this.state = {
	  
        };
    }


    render() {
        return  <div className="app">
            <div ref="top" id="top">
                <h1><Link to="/">Tubity</Link></h1>
                <menu>
                    <Link to="/about">About</Link>
                    <a href="https://github.com/Jarosh/tubity-ui" target="_blank">GitHub</a>
                </menu>
            </div>
            <div ref="app" id="app">
                {React.cloneElement(this.props.children, { app: this })}
            </div>
        </div>
    }


}


try {
    ReactDOM.render((<Router history={ window.location.protocol.match(/^https?:?$/) ? browserHistory : hashHistory}>
        <Route path="/" component={App}>
            <IndexRoute component={AppIndex}/>
            <Route path="about" component={AppAbout}/>
            <Route path="*" component={AppIndex}/>
        </Route>
    </Router>), document.getElementById('tubity-ui'));
} catch(exc) {
    throw exc;
}
