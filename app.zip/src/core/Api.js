import React from 'react';
import ReactDOM from 'react-dom';


export class Api extends React.Component {


    constructor(props, context) {
        super(props, context);
    }


    api(api, alias=null, options={credentials: 'include'}) {

        api = api.replace(/^\/*/, '');

        return {

            get: function (data={}) {
                var arg = [];
                for (let k in data) {
                    if (data.hasOwnProperty(k))
                        arg.push(k+'='+data[k]);
                }
                if (arg.length) {
                    if (api.indexOf('?')<0)
                        api += '?';
                    api += ((api.slice(-1)!='?' && api.slice(-1)!='&') ? '&' : '') + arg.join('&');
                }
                return this.call();
            },

            delete: function (data={}) {
                var arg = [];
                for (let k in data) {
                    if (data.hasOwnProperty(k))
                        arg.push(k+'='+data[k]);
                }
                if (arg.length) {
                    if (api.indexOf('?')<0)
                        api += '?';
                    api += ((api.slice(-1)!='?' && api.slice(-1)!='&') ? '&' : '') + arg.join('&');
                }
                return this.call('DELETE');
            },

            post: function (data={}) {
                return this.call('POST', data);
            },

            put: function (data={}) {
                return this.call('PUT', data);
            },

            call: function (method='GET', data={}, json=true) {
                options['method'] = method.toUpperCase().trim();

                options['headers'] = {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                };

                var r = null;

                var key = alias ? alias.trim() : (options['method']+' '+Math.random()+' '+api);

                if (options['method']=='POST' || options['method']=='PUT') {
                    if (json) {
                        options['body'] = JSON.stringify(data);
                    } else {
                        var form = new FormData();
                        for (var k in data) {
                            form.append(k, data[k]);
                        }
                        options['body'] = form;
                    }
                }

                if (typeof Api.calls[key] === 'undefined')
                    Api.calls[key] = [];

                //console.log(JSON.stringify(Api.calls[key]));

                for (var i=0, l=Api.calls[key].length; i<l; i++) {
                    if (Api.calls[key][i][1]==api) {
                        Api.calls[key].splice(i+1, Api.calls[key].length-i-1);
                        break;
                    }
                }

                if ( !Api.calls[key].length || Api.calls[key][Api.calls[key].length-1][1] != api ) {
                    Api.calls[key].push([false,api,options]);
                }

                var exe = ()=>{
                    if (Api.calls[key].length && !Api.calls[key][0][0]) {
                        //console.log( 'API :: ' + Api.calls[key].length + ' :: ' + key + ' :: ' + api );
                        Api.calls[key][0][0] = true;
                        r = fetch('//'+APP.SERVER.api+'/'+Api.calls[key][0][1], Api.calls[key][0][2])
                            .then((res) => {
                                if (res.status<200 || res.status>=300)
                                    throw Promise.resolve(res);
                                return res.json();
                            })
                            .then((res) => {
                                Api.calls[key].shift();
                                exe();
                                return (res instanceof Object)
                                    ? res
                                    : Promise.reject('Malformed JSON received.');
                            })
                            .catch((exc) => {
                                Api.calls[key].shift();
                                exe();
                                if (!(exc instanceof Promise)) {
                                    //alert('App.api(' + api + ') :\r\n\t' + exc);
                                    exc = null;
                                }
                                return Promise.reject(exc);
                            });
                    }
                };

                exe();

                return r ? r : Promise.reject(777);
            }

        };
    }

}

Api.calls = {};
