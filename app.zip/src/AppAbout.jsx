import React from 'react';
import ReactDOM from 'react-dom';


export class AppAbout extends React.Component {


    render() {
        return  <div>
            Lorem ipsum dolor sit amet...
        </div>
    }


}
