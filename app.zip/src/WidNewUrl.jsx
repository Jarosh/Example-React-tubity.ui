import React from 'react';
import Clipboard from 'react-clipboard.js';
import {Api as CoreApi} from './core/Api';


export class WidNewUrl extends CoreApi {




    constructor(props, context) {
        super(props, context);

        this.state = {
            result: null
        };
    }


    onClear() {
        this.setState({result:null});
    }


    onShorten() {
        this.api('/s').post({
            "url": this.refs.txt__Url.value
        })
            .then((res) => {
                //if (!res.shorten_url)
                //    throw Promise.reject();
                this.setState({result:res});
                this.pushHistory(res);
            })
            .catch((exc) => {
                alert(JSON.stringify(exc));
                /*
                if (exc instanceof Promise)
                    exc
                        .then((v) => {
                            switch (v.status) {
                                case 404:
                                    APP.INSTANCE.showAlert(
                                        <div>
                                            <p><b>{APP.t(this.constructor.name,'msg_unexisting_email','There is no user with such email.')}</b></p>
                                            <button className="btn" onClick={ ()=>{APP.INSTANCE.hideDialog();} }>Close</button>
                                        </div>,
                                        5000
                                    );
                                    break;
                                default:
                                    APP.INSTANCE.showAlert(
                                        <div>
                                            <p><b>{APP.t(this.constructor.name,'msg_unhandled_error','UNHANDLED ERROR')}</b></p>
                                            <button className="btn" onClick={ ()=>{APP.INSTANCE.hideDialog();} }>Close</button>
                                        </div>,
                                        5000
                                    );
                                    break;
                            }
                        });
                        */
            });
    }



    pushHistory(item) {
        var tmp = JSON.parse(localStorage.getItem('history'));
        if (!tmp)
            tmp = [];
        tmp.push([
            (new Date()).getTime(),
            item.url,
            item.shorten_url
        ]);
        localStorage.setItem('history', JSON.stringify(tmp));
    }


    dropHistory(item) {

    }


    render() {
        return <div>
            { !this.state.result
                ? <input ref="txt__Url" className="url" type="text" placeholder="Your original URL here" />
                : <input ref="txt__Url" className="url" type="text" value={this.state.result.shorten_url} />
            }
            { !this.state.result
                ? <button onClick={this.onShorten.bind(this)}>Shorten URL</button>
                : <Clipboard data-clipboard-text={this.state.result.shorten_url} onSuccess={this.onClear.bind(this)}>Copy &amp; Clean</Clipboard>
            }
        </div>
    }

}
