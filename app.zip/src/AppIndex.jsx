import React from 'react';
import ReactDOM from 'react-dom';
import {WidNewUrl} from './WidNewUrl.jsx';
import {WidLogger} from './WidLogger.jsx';


export class AppIndex extends React.Component {


    render() {
        return  <div>
            <WidNewUrl></WidNewUrl>
            <WidLogger></WidLogger>
        </div>
    }


}
