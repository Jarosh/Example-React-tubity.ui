import React from 'react';
import {IncLogItem} from './IncLogItem.jsx';


export class WidLogger extends React.Component {


    render() {
        return <div>
            <table>
                <thead>
                    <tr>
                        <td></td>
                        <td>Original URL</td>
                        <td>Created</td>
                        <td>Short URL</td>
                    </tr>
                </thead>
                <tbody>
                { JSON.parse(localStorage.getItem('history')).reverse().map((v,i)=>{
                    return <IncLogItem item={v} />
                }) }
                </tbody>
            </table>
        </div>
    }

}
