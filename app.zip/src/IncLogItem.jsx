import React from 'react';


export class IncLogItem extends React.Component {


    render() {
        return <tr>
            <td><span onClick={()=>{alert(99);}}>&times;</span></td>
            <td>{this.props.item[1]}</td>
            <td>{ (new Date(this.props.item[0])).toLocaleDateString() + ' ' + (new Date(this.props.item[0])).toLocaleTimeString() }</td>
            <td>
                <a href={this.props.item[2]} target="_blank">{this.props.item[2]}</a>
            </td>
        </tr>
    }

}
